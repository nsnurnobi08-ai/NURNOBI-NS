from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.widget import Widget
from kivy.uix.image import Image
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.floatlayout import FloatLayout
from kivy.graphics import Color, Rectangle
from random import choice, uniform

class RacingGame(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.score = 0
        self.coins = 0
        self.speed = 1.0
        self.nitro = 100
        self.game_over = False

        self.bg = Image(
            source="racing_background.png",
            allow_stretch=True,
            keep_ratio=False,
            size_hint=(1,1),
            pos_hint={"x":0,"y":0}
        )
        self.add_widget(self.bg)

        # Simple animated car/enemies over the generated racing scene.
        self.car = Image(
            source="car_blue.png",
            size_hint=(None,None),
            size=(120,190),
            pos_hint={"center_x":.5,"y":.08}
        )
        self.add_widget(self.car)

        self.enemy = Image(
            source="enemy_red.png",
            size_hint=(None,None),
            size=(95,150),
            pos_hint={"center_x":.38,"y":.78}
        )
        self.add_widget(self.enemy)

        self.score_label = Label(
            text="SCORE 0   🪙 0",
            font_size="22sp",
            bold=True,
            size_hint=(.5,.08),
            pos_hint={"x":.02,"top":.98}
        )
        self.add_widget(self.score_label)

        self.nitro_label = Label(
            text="NITRO 100%",
            font_size="18sp",
            bold=True,
            size_hint=(.3,.07),
            pos_hint={"right":.98,"top":.97}
        )
        self.add_widget(self.nitro_label)

        self.left = Button(
            text="◀", font_size="34sp",
            size_hint=(.18,.14), pos_hint={"x":.03,"y":.03}
        )
        self.left.bind(on_press=lambda *_: self.move(-1))
        self.add_widget(self.left)

        self.right = Button(
            text="▶", font_size="34sp",
            size_hint=(.18,.14), pos_hint={"x":.23,"y":.03}
        )
        self.right.bind(on_press=lambda *_: self.move(1))
        self.add_widget(self.right)

        self.nitro_btn = Button(
            text="NITRO", font_size="20sp",
            size_hint=(.22,.14), pos_hint={"right":.97,"y":.03}
        )
        self.nitro_btn.bind(on_press=self.use_nitro)
        self.add_widget(self.nitro_btn)

        self.restart = Button(
            text="RESTART", font_size="22sp",
            size_hint=(.3,.12), pos_hint={"center_x":.5,"center_y":.45}
        )
        self.restart.opacity = 0
        self.restart.disabled = True
        self.restart.bind(on_press=self.reset)
        self.add_widget(self.restart)

        self.car_x = .50
        self.enemy_y = .78
        self.enemy_x = .38
        self.boost = 1.0
        Clock.schedule_interval(self.update, 1/60)

    def move(self, direction):
        if self.game_over: return
        self.car_x = max(.25, min(.75, self.car_x + direction*.055))
        self.car.pos_hint["center_x"] = self.car_x

    def use_nitro(self, *_):
        if not self.game_over and self.nitro > 0:
            self.boost = 2.4
            self.nitro = max(0, self.nitro - 4)

    def update(self, dt):
        if self.game_over: return

        self.enemy_y -= .0045 * self.speed * self.boost
        self.enemy.pos_hint["y"] = self.enemy_y

        if self.enemy_y < -.12:
            self.enemy_y = .78
            self.enemy_x = uniform(.30,.70)
            self.enemy.pos_hint["center_x"] = self.enemy_x
            self.score += 10
            self.coins += 1
            self.speed = min(3.0, self.speed + .015)

        self.boost = max(1.0, self.boost - .035)
        self.nitro = min(100, self.nitro + .08)

        self.score_label.text = f"SCORE {self.score}   🪙 {self.coins}"
        self.nitro_label.text = f"NITRO {int(self.nitro)}%"

        # Approximate collision using widget rectangles.
        if self.car.collide_widget(self.enemy):
            self.end_game()

    def end_game(self):
        self.game_over = True
        self.restart.opacity = 1
        self.restart.disabled = False
        self.score_label.text = f"GAME OVER  |  SCORE {self.score}"

    def reset(self, *_):
        self.score = 0
        self.coins = 0
        self.speed = 1.0
        self.nitro = 100
        self.game_over = False
        self.boost = 1.0
        self.enemy_y = .78
        self.enemy_x = .38
        self.car_x = .50
        self.car.pos_hint["center_x"] = self.car_x
        self.enemy.pos_hint["center_x"] = self.enemy_x
        self.enemy.pos_hint["y"] = self.enemy_y
        self.restart.opacity = 0
        self.restart.disabled = True

class NSNurnobiApp(App):
    def build(self):
        Window.clearcolor = (0,0,0,1)
        return RacingGame()

if __name__ == "__main__":
    NSNurnobiApp().run()