NS NURNOBI RACING — Android build project

1) Install Python, Java 17/21, Buildozer and Android build dependencies.
2) Open this folder in Linux/WSL.
3) Run:
   buildozer android debug
4) The APK will be created inside the bin/ folder.

The generated racing image is used as the game's visual background.